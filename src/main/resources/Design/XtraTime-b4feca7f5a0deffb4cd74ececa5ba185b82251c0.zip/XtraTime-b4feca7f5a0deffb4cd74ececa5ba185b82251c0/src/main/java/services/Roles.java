package services;

public enum Roles {ADMIN, CLIENT, LOCATEUR, LIVREUR}
